// Please don't change the pre-written code
// make the necessary imports for creating book schema named 'bookSchema'
import mongoose from "mongoose";

// Start writing your code here
 const bookSchema =  new mongoose.Schema({
    title : String,
    author : mongoose.Schema.Types.ObjectId,
    genre : {type: String, enum : ['Fiction' , 'Non-Fiction' , 'Science Fiction' , 'Mystery' , 'Fantasy' , 'other']},
    copies : { type: Number, min: 1},
    availableCopies:  { type: Number, min: 1}
 })

export default bookSchema;
