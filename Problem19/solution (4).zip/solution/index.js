// Please don't change the pre-written code

const express = require("express");
const server = express();
const path = require("path");
const fs = require("fs");

const renderStatic = () => {
  // Write your code here
  // Define the path to the static folder containing 'index.html'
  const staticFolderPath = path.join(__dirname, "public");

  // Handle GET requests to http://localhost:5000/index.html
  server.get("/index.html", (req, res) => {
    // Construct the full path to 'index.html'
    const indexPath = path.join(staticFolderPath, "index.html");

    // Check if the file exists
    if (fs.existsSync(indexPath)) {
      // Read the 'index.html' file and send it as the response
      fs.readFile(indexPath, "utf8", (err, data) => {
        if (err) {
          res.status(500).send("Internal Server Error");
        } else {
          res.send(data);
        }
      });
    } else {
      // If the file doesn't exist, return a 404 Not Found response
      res.status(404).send("Not Found");
    }
  });
};

server.get("/", (req, res) => {
  return res.send("get method called!");
});

renderStatic();

module.exports = { renderStatic, server };
