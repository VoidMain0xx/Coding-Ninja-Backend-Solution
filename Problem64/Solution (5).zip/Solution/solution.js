export const AWS_LINK = "http://51.20.43.8:3000";
export const PORT = 3000;
