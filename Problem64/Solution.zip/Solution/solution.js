export const AWS_LINK = "AWS_LINK";
export const PORT = 3000;
