// Please don't change the pre-written code
// Import the necessary modules here
import { cartModel } from "../model/cart.model.js";

export const addToCartController = (req, res) => {
  // Write your code here
  const {productId , quantity} = req.query;
  const userId = req.userId;
  cartModel.add(productId , userId , quantity );
  res.status(201).json({
    "success": true,
    "item": [
    {
    "id": id,
    "userId": userId,
    "productId": productId,
    "quantity": quantity
    },
    {
    "id": id,
    "userId": userId,
    "productId": productId,
    "quantity": quantity
    }
    ]
    })
};

export const removeFromCartController = (req, res) => {
  // Write your code here
  const userID = req.userID;
  const cartItemID = req.params.id;
  const {productId , quantity} = req.query;
  const userId = req.userId;
  const error = cartModel.removeFromCartController(
      cartItemID,
      userID
  );
  if (error) {
     return res.status(404).json(
      {
        "success": false,
        "msg": "operation not allowed"
        }
     )
  }
  return res
  .status(200)
  .json(
    {
      "success": true,
      "deletedCartItem": {
      "id": id,
      "userId": userID,
      "productId": productId,
      "quantity": quantity
      }
      }
  );
};
