// Please don't change the pre-written code
// Import the necessary modules here
import { addUser, confirmLogin } from "../model/user.model.js";

export const registerUser = (req, res, next) => {
  // Write your code here
  const { name, email, password } = req.body;
  const user = addUser(req.body);
  res.status(201).send(user);
};

export const loginUser = (req, res) => {
  // Write your code here
  const result = confirmLogin(req.body.email && req.body.password);
  if (!result) {
    res.status(404).send("invalid user");
  } else {
    res.status(201).send('successful')
  }
};
