// Import the necessary modules here
import mongoose from "mongoose";

// Start creating your user schema here
export const userSchema = new mongoose.Schema({
    name: { type: String,  required: true, minlength: [3, "Name Should be greater than 3 characters"] },
    email: {
        type: String, unique: true, required: true,
        match: [/^([a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})$/, "Please enter a valid email"]
    },
    mobile: {
        type: String,
        unique: true, required: true,
    },
    age :{
        type : Number,
        required: true,
        min : [0 , "The age should start from 0"],
        max : 100
    },
    password: {type: String, 
        required: true,
    },
    type:{
        type : String ,required: true, enum : ["Student" , 'Fresher' , 'experienced' ]
    }
})
