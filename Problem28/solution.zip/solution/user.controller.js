export const newUser = (req, res) => {
 
};
