export const getTweets = (req, res) => {
  return res.status(200).json({ message: "GET tweets called!" });
  // res.send("GET tweets called!");
};

export const createTweet = (req, res) => {
  return res.status(201).json({ message: "POST tweet created!" });
  // res.send("POST tweet created!");
};