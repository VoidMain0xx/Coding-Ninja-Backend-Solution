import express from "express";
import {
    getTweets,
    createTweet,
  } from "../tweet/tweet.controller.js";

const Router = express.Router();

Router.get('/api/tweets' , getTweets);
Router.post('/api/tweets' , createTweet);

export default Router;