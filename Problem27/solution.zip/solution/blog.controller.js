// Please don't change the pre-written code

export const validateBlog = (req, res) => {
  // Write your code here
  const {title, description , image} = req.body;
  let errorss = [];
  if(!title || title.trim() == ' '){
      errorss.push('enter a valid Tittle')
  }
  if(!description){
    errorss.push('enter a proper description');
  }
  try {
    let validurl = new url(image)
  } catch (err) {
    errorss.push ('enter a valid url');
  }

  if(errorss.length > 0){
   return res.render("addBlog" , {errors : errorss[0]});
  }


  res.status(201).render("addBlog", { errors: null, success: true });
};
export const renderBlogForm = (req, res) => {
  res.render("addBlog", { errors: null, success: false });
};
